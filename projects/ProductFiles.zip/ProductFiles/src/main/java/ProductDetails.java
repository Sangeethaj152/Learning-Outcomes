import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.DBConnection;

/**
* Servlet implementation class ProductDetails
*/
@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
        private static final long serialVersionUID = 1L;
       
    /**
* @see HttpServlet#HttpServlet()
*/
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

        /**
         * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
         */
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                // TODO Auto-generated method stub
                
                try {
                        PrintWriter out = response.getWriter();
                        out.println("<html><body>");
                         
                        getServletContext().getResourceAsStream("/WEB-INF/config.properties");
                        new Properties();
                        
                        //connection information
                        DBConnection conn = new DBConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "Sangi@152");
                        Statement stmt = conn.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                        
                        
                        //query the table and get all information
                        ResultSet rst = stmt.executeQuery("select * from ecommerce.products");
                        
                        //find what the user typed into the search box
                        String productSearch = request.getParameter("search");
                        //out.println(productSearch);
                        
                        //user hasn't typed anything so display table
                        if(productSearch == null)
                        {	out.println("<table width=25% border=1>");
                        out.print("<tr><th>productID</th><th>Category</th><th>Name</th><th>Price</th></tr>");
                        	
	                        out.println("The following are the elements in the table" + "<Br>" + "<Br>");
	                        //simple while loop to print all elements in table
	                        while (rst.next()) {
	                        	out.println("<tr>");
	                        	out.print("<td>"+rst.getInt("productID")+"</td>");
                				out.print("<td>"+rst.getString("Category")+"</td>");
                				out.print("<td>"+rst.getString("Name")+"</td>");
                				out.print("<td>"+rst.getInt("Price")+"</td>");
                				out.println("</tr>");
	                        }
                        }
                        //user typed something
                        else
                        {
                        	//select the row corresponding to the id number
                        	String sql_res= "select * from ecommerce.products where productID=" + productSearch;
                            ResultSet inTable = stmt.executeQuery(sql_res);
                            out.println("<table width=25% border=1>");
                            out.print("<tr><th>productID</th><th>Category</th><th>Name</th><th>Price</th></tr>");
                            
                            //if not empty then print all product details
                            if(inTable.next()) {
                            	out.println("<tr>");
                            	out.println("<td>"+inTable.getString("productID")+"</td>");
                				out.print("<td>"+inTable.getString("Category")+"</td>");
                				out.print("<td>"+inTable.getString("Name")+"</td>");
                				out.print("<td>"+inTable.getInt("Price")+"</td>");
                				out.println("</tr>");
                                                   
                            }
                           
                        
                            //empty so print error message
                          else{
                        	  out.println("There was no element with product ID: " + productSearch + " found in the table, please try again");
                            	
                            }
                        }              
                        
                    	
                        stmt.close();
                        
                        
                        
                        conn.closeConnection();
                        
                } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
        }

        /**
         * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
         */
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                // TODO Auto-generated method stub
                doGet(request, response);
        }

}

