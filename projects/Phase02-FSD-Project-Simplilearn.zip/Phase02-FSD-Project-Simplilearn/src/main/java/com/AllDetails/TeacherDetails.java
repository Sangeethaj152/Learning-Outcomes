package com.AllDetails;

public class TeacherDetails {

}